# sample-module
This is a sample terraform module that is an example of how to publish modules to app.tfmodule.com with CI
